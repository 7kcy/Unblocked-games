# My Games Library (GitHub Pages ready)

This is a simple single-page site that showcases / embeds browser games.
It is intended for **educational / open-source** games and demos — do NOT host copyrighted or paid games you don't have permission to publish.

## What is included
- `index.html`, `styles.css`, `scripts.js` — single-page site.
- Uses `localStorage` to save games you add via the **Add game** button.
- Example games: 2048, Hextris, a Tetris demo.

## How to deploy (GitHub Pages)
1. Create a GitHub repository.
2. Upload the files from this ZIP to the repository root.
3. In the repo Settings → Pages, choose the `main` branch and `/ (root)` folder and save.
4. GitHub will publish at `https://<username>.github.io/<repo>/`. Open that URL on your Chromebook.

If your school blocks it, request a whitelist from your admin and explain it's a student project with only open-source/educational games.

## Notes & tips
- Some external sites block embedding with `X-Frame-Options` or via Content Security Policy; when embedding fails, use *Open* to open the game in a new tab.
- To make the list permanent across machines, you can manually edit `data.json` in the repo and modify `scripts.js` to fetch it (advanced).
- If you want, I can add a `games.json` and serverless persistence instructions (e.g., using GitHub Actions to commit changes).
