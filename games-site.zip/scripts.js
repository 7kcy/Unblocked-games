// Client-side logic: load examples, search, open, embed, add, persist to localStorage
const gamesGrid = document.getElementById('gamesGrid');
const searchInput = document.getElementById('search');
const addGameBtn = document.getElementById('addGameBtn');
const resetBtn = document.getElementById('resetBtn');
const embedArea = document.getElementById('embedArea');
const embedFrame = document.getElementById('embedFrame');
const embedTitle = document.getElementById('embedTitle');
const closeEmbed = document.getElementById('closeEmbed');

const STORAGE_KEY = 'my-games-library-v1';

const exampleGames = [
  {
    "title": "2048",
    "desc": "Classic sliding tile puzzle (MIT-licensed clones exist).",
    "url": "https://play2048.co/"
  },
  {
    "title": "Hextris",
    "desc": "Fast-paced arcade puzzle (open-source port).",
    "url": "https://hextris.github.io/"
  },
  {
    "title": "JS13k Tetris (example)",
    "desc": "Small, embeddable Tetris demo.",
    "url": "https://tetris.flohoff.de/"
  }
];

function save(list){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}
function load(){
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    if(!raw) return null;
    return JSON.parse(raw);
  }catch(e){
    return null;
  }
}
function restoreExamples(){
  save(exampleGames);
  render(exampleGames);
}
function render(list){
  gamesGrid.innerHTML = '';
  list.forEach(g=>{
    const el = document.createElement('article');
    el.className = 'card';
    el.dataset.title = g.title || '';
    el.innerHTML = `<h3>${g.title}</h3>
      <p>${g.desc || ''}</p>
      <div class="card-actions">
        <button class="open-btn" data-url="${g.url}" title="Open in a new tab">Open</button>
        <button class="embed-btn" data-url="${g.url}" title="Embed in page">Embed</button>
      </div>`;
    gamesGrid.appendChild(el);
  });
}

searchInput.addEventListener('input', () => {
  const q = searchInput.value.toLowerCase();
  document.querySelectorAll('.card').forEach(card => {
    const t = card.dataset.title.toLowerCase();
    card.style.display = t.includes(q) ? '' : 'none';
  });
});

gamesGrid.addEventListener('click', (e) => {
  const btn = e.target.closest('button');
  if (!btn) return;
  const url = btn.dataset.url;
  const card = btn.closest('.card');
  const title = card?.querySelector('h3')?.innerText || '';
  if (btn.classList.contains('open-btn')) {
    window.open(url, '_blank', 'noopener');
  } else if (btn.classList.contains('embed-btn')) {
    embedTitle.textContent = title;
    embedFrame.src = url;
    embedArea.classList.remove('hidden');
    embedArea.setAttribute('aria-hidden', 'false');
  }
});

closeEmbed.addEventListener('click', () => {
  embedFrame.src = '';
  embedArea.classList.add('hidden');
  embedArea.setAttribute('aria-hidden', 'true');
});

// Add game via prompt (simple)
addGameBtn.addEventListener('click', () => {
  const title = prompt('Game title (short)');
  if(!title) return;
  const url = prompt('Game URL (must be HTTPS or relative path)');
  if(!url) return;
  const desc = prompt('Short description (optional)') || '';
  const current = load() || exampleGames;
  current.push({title, desc, url});
  save(current);
  render(current);
});

resetBtn.addEventListener('click', () => {
  if(confirm('Restore the example list (this will replace your saved list)?')){
    restoreExamples();
  }
});

// Initialize
const existing = load();
if(existing && Array.isArray(existing) && existing.length) {
  render(existing);
} else {
  restoreExamples();
}
