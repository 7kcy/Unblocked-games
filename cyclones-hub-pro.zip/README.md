# Cyclones Hub — Pro Neon Edition

Black + orange neon-themed game hub designed for GitHub Pages.
Drop the files in a repo and enable Pages (main branch / root).

Files:
- index.html
- styles.css
- scripts.js
- README.md
- thumbs/ (SVG thumbnails used for each starter game)

Starter games included (links):
- 2048 — https://play2048.co/
- Tetris — https://tetris.flohoff.de/
- Hextris — https://hextris.github.io/
- Snake — https://sneky.surge.sh/
- Dino — https://chromedino.com/
- Minesweeper — https://minesweeperonline.com/

Notes:
- Some sites block embedding in an iframe; use 'Play' to open in a new tab when that happens.
- The Add Game button saves entries in browser localStorage on the device used.
- If you want persistent shared storage, I can add a simple JSON + GitHub Actions workflow to commit changes.
