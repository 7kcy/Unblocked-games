// Cyclones Hub - Pro Neon Edition
const gamesGrid = document.getElementById('gamesGrid');
const searchInput = document.getElementById('search');
const addGameBtn = document.getElementById('addGameBtn');
const embedArea = document.getElementById('embedArea');
const embedFrame = document.getElementById('embedFrame');
const embedTitle = document.getElementById('embedTitle');
const closeEmbed = document.getElementById('closeEmbed');
const openNewTab = document.getElementById('openNewTab');

const STORAGE_KEY = 'cyclones-hub-v1';

const starterGames = [
  { title: '2048', desc: 'Slide tiles to combine numbers.', url: 'https://play2048.co/', thumb: 'thumbs/2048.svg' },
  { title: 'Tetris', desc: 'Classic falling blocks.', url: 'https://tetris.flohoff.de/', thumb: 'thumbs/tetris.svg' },
  { title: 'Hextris', desc: 'Rotating hex puzzle.', url: 'https://hextris.github.io/', thumb: 'thumbs/hextris.svg' },
  { title: 'Snake', desc: 'Classic snake game.', url: 'https://sneky.surge.sh/', thumb: 'thumbs/snake.svg' },
  { title: 'Dino', desc: 'Chrome offline-style runner.', url: 'https://chromedino.com/', thumb: 'thumbs/dino.svg' },
  { title: 'Minesweeper', desc: 'Find all the mines.', url: 'https://minesweeperonline.com/', thumb: 'thumbs/minesweeper.svg' }
];

function save(list){ localStorage.setItem(STORAGE_KEY, JSON.stringify(list)); }
function load(){ try{ return JSON.parse(localStorage.getItem(STORAGE_KEY)); }catch(e){return null} }

function render(list){
  gamesGrid.innerHTML = '';
  list.forEach((g, idx) => {
    const card = document.createElement('article');
    card.className = 'card';
    card.innerHTML = `
      <div class="tag-badge">${idx+1}</div>
      <div class="thumb"><img src="${g.thumb}" alt="${g.title} thumbnail"></div>
      <h3 class="title">${g.title}</h3>
      <p class="desc">${g.desc||''}</p>
      <div class="actions">
        <button class="btn play" data-url="${g.url}">Play</button>
        <button class="btn embed" data-url="${g.url}">Embed</button>
      </div>
    `;
    gamesGrid.appendChild(card);
  });
}

function init(){
  const existing = load();
  if(existing && existing.length){
    render(existing);
  } else {
    save(starterGames);
    render(starterGames);
  }
}

searchInput.addEventListener('input', ()=>{
  const q = searchInput.value.toLowerCase();
  document.querySelectorAll('.card').forEach(card=>{
    const t = card.querySelector('.title').innerText.toLowerCase();
    card.style.display = t.includes(q) ? '' : 'none';
  });
});

gamesGrid.addEventListener('click', (e)=>{
  const btn = e.target.closest('button');
  if(!btn) return;
  const url = btn.dataset.url;
  const title = btn.closest('.card').querySelector('.title').innerText;
  if(btn.classList.contains('play')){
    window.open(url, '_blank', 'noopener');
  } else if(btn.classList.contains('embed')){
    embedTitle.textContent = title;
    embedFrame.src = url;
    openNewTab.href = url;
    embedArea.classList.remove('hidden');
    embedArea.setAttribute('aria-hidden','false');
  }
});

closeEmbed.addEventListener('click', ()=>{
  embedFrame.src = '';
  embedArea.classList.add('hidden');
  embedArea.setAttribute('aria-hidden','true');
});

addGameBtn.addEventListener('click', ()=>{
  const title = prompt('Game title (short)');
  if(!title) return;
  const url = prompt('Game URL (must be HTTPS)');
  if(!url) return;
  const desc = prompt('Short description (optional)')||'';
  const list = load() || starterGames;
  list.push({title,desc,url,thumb:'thumbs/default.svg'});
  save(list);
  render(list);
});

// Initialize
init();